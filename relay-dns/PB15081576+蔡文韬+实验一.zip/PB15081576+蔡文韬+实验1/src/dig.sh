dig baidu.com @127.0.0.1
dig gin.ru  @127.0.0.1
dig hotbar.com @127.0.0.1
dig www.9p.com @127.0.0.1
dig test1 @127.0.0.1
dig test2 @127.0.0.1
dig sohu.com @127.0.0.1
dig jd.com @127.0.0.1
dig sina.com.cn @127.0.0.1
dig weibo.com @127.0.0.1

